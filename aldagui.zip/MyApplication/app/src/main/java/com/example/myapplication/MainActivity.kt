package com.example.grade

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.example.myapplication.R

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var total = 0
        var ave: Int


        var java = editTextJava.text.toString().toInt()
        var net = editTextNetwork.text.toString().toInt()
        var database = editTextDatabase.text.toString().toInt()


        buttonTotal.setOnClickListener {
            total = java + net + database
            editTextTotal.setText(total)
        }

        buttonAve.setOnClickListener {
            ave = total / 3
            editTextAve.setText(ave)

        }
    }}