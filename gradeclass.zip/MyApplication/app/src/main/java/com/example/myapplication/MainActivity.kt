package com.example.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        var num1=findViewById<View>(R.id.editTextJava) as EditText
//        var num2=findViewById<View>(R.id.textView2) as EditText

        var java = 0
        var network = 0
        var database = 0
        var total = 0

        java = editTextJava.text.toString().toInt()

        total = java + 100 + 90

        buttonTotal.setOnClickListener {
            editTextTotal.setText(total)
        }



    }
}
